import subprocess
import re
import mysql.connector
from flask import Flask, jsonify, request
from flask_cors import CORS  # Importar o CORS

app = Flask(__name__)

# Permitir CORS para todas as origens
CORS(app)

# Conectar ao banco de dados
conn = mysql.connector.connect(
    host="localhost",
    user="root",
    password="Panela-123",
    database="monitoramento_rede"
)

def parse_nmap_output(nmap_output):
    devices = []
    blocks = re.split(r"\n(?=Nmap scan report)", nmap_output.strip())

    for block in blocks:
        ip_match = re.search(r"Nmap scan report for (\d+\.\d+\.\d+\.\d+)", block)
        mac_match = re.search(r"MAC Address: ([0-9A-F:]+) \((.*?)\)", block)

        if ip_match:
            ip = ip_match.group(1)
            mac = mac_match.group(1) if mac_match else "Desconhecido"
            fabricante = mac_match.group(2) if mac_match else "Desconhecido"

            # Usar o cursor com 'with' para garantir que ele será fechado após o uso
            with conn.cursor() as cursor:
                cursor.execute("SELECT nome_personalizado FROM dispositivos WHERE mac_address = %s", (mac,))
                result = cursor.fetchone()
                nome_personalizado = result[0] if result else ""

                # Se o dispositivo não existir no banco, salvar
                if not result:
                    cursor.execute("INSERT INTO dispositivos (mac_address, ip, fabricante) VALUES (%s, %s, %s)", 
                                   (mac, ip, fabricante))
                    conn.commit()

            devices.append({"ip": ip, "mac": mac, "fabricante": fabricante, "nome_personalizado": nome_personalizado})

    return devices

@app.route('/scan_network', methods=['GET'])
def scan_network():
    try:
        # Executar o comando Nmap
        result = subprocess.check_output(["nmap", "-sn", "192.168.3.0/24"], universal_newlines=True)
        # Retornar a resposta com os dispositivos encontrados
        return jsonify({"devices": parse_nmap_output(result)})
    except subprocess.CalledProcessError as e:
        return jsonify({"error": f"Nmap error: {str(e)}"}), 500
    except Exception as e:
        return jsonify({"error": f"Erro desconhecido: {str(e)}"}), 500

@app.route('/editar_dispositivo', methods=['POST'])
def editar_dispositivo():
    data = request.json
    mac, nome_personalizado = data.get("mac"), data.get("nome_personalizado")

    if not mac or not nome_personalizado:
        return jsonify({"error": "MAC Address e Nome são obrigatórios"}), 400

    try:
        # Atualizar o nome do dispositivo no banco de dados
        with conn.cursor() as cursor:
            cursor.execute("UPDATE dispositivos SET nome_personalizado = %s WHERE mac_address = %s", 
                           (nome_personalizado, mac))
            conn.commit()
        return jsonify({"message": "Nome atualizado com sucesso"})
    except mysql.connector.Error as e:
        return jsonify({"error": f"Erro no banco de dados: {str(e)}"}), 500
    except Exception as e:
        return jsonify({"error": f"Erro desconhecido: {str(e)}"}), 500

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0')
