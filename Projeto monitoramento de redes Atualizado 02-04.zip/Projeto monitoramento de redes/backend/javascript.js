// Função para buscar os dispositivos
async function fetchDevices() {
    try {
        const response = await fetch('http://localhost:5000/scan_network'); // URL da API
        const data = await response.json(); // Convertendo a resposta para JSON
        
        console.log('Dispositivos:', data); // Log para verificar os dados retornados
        
        if (data.devices) {
            const tbody = document.querySelector('.tabela-dispositivos tbody');
            tbody.innerHTML = ''; // Limpar tabela antes de adicionar os dispositivos
            
            // Adicionar cada dispositivo à tabela
            data.devices.forEach(device => {
                const row = document.createElement('tr');
                
                // Coluna de Nome Personalizado
                const tdNome = document.createElement('td');
                tdNome.textContent = device.nome_personalizado || 'Não definido';
                row.appendChild(tdNome);
                
                // Coluna de Fabricante
                const tdFabricante = document.createElement('td');
                tdFabricante.textContent = device.fabricante;
                row.appendChild(tdFabricante);
                
                // Coluna de IP
                const tdIP = document.createElement('td');
                tdIP.textContent = device.ip;
                row.appendChild(tdIP);
                
                // Coluna de MAC
                const tdMAC = document.createElement('td');
                tdMAC.textContent = device.mac;
                row.appendChild(tdMAC);
                
                // Coluna de Editar
                const tdEditar = document.createElement('td');
                const btnEditar = document.createElement('button');
                btnEditar.textContent = 'Editar';
                btnEditar.onclick = () => editarDispositivo(device.mac); // Função para editar
                tdEditar.appendChild(btnEditar);
                row.appendChild(tdEditar);

                tbody.appendChild(row);
            });
        } else {
            console.log('Nenhum dispositivo encontrado.');
        }
    } catch (error) {
        console.error('Erro ao buscar dispositivos:', error);
    }
}

// Função para editar o dispositivo
function editarDispositivo(mac) {
    const nomePersonalizado = prompt("Digite o novo nome personalizado:");

    if (nomePersonalizado) {
        // Enviar a requisição para editar o dispositivo
        fetch('http://localhost:5000/editar_dispositivo', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                mac: mac,
                nome_personalizado: nomePersonalizado
            })
        })
        .then(response => response.json())
        .then(data => {
            if (data.message) {
                alert(data.message);
                fetchDevices(); // Atualizar a lista de dispositivos após a edição
            } else if (data.error) {
                alert('Erro: ' + data.error);
            }
        })
        .catch(error => {
            console.error('Erro ao editar dispositivo:', error);
        });
    }
}

// Carregar os dispositivos quando a página carregar
document.addEventListener('DOMContentLoaded', fetchDevices);
