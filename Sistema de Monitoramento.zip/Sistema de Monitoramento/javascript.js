const API_DEVICES_URL = 'http://localhost:5000/devices';
const API_STATS_URL = 'http://localhost:5000/stats';

// Buscar dispositivos
async function fetchDevices() {
  try {
    const res = await fetch(API_DEVICES_URL);
    if (!res.ok) throw new Error('Erro na requisição');
    const data = await res.json();

    if (data.status !== 'sucesso' && data.status !== 'success') {
      throw new Error(data.mensagem || data.message || 'Erro na API');
    }

    return data.devices || data.dispositivos || [];
  } catch (error) {
    console.error('Erro ao buscar dispositivos:', error);
    return null;
  }
}

// Renderizar tabela de dispositivos
function renderDevices(devices) {
  const tbody = document.getElementById('devicesTableBody');
  if (!devices) {
    tbody.innerHTML = `<tr><td colspan="6">Erro ao carregar dispositivos.</td></tr>`;
    return;
  }
  if (devices.length === 0) {
    tbody.innerHTML = `<tr><td colspan="6">Nenhum dispositivo encontrado.</td></tr>`;
    return;
  }

  tbody.innerHTML = devices.map(d => `
    <tr class="${d.status.toLowerCase()}">
      <td>${d.nome}</td>
      <td>${d.status}</td>
      <td>${d.ip_address}</td>
      <td>${d.mac_address}</td>
      <td>${d.ultima_conexao || '-'}</td>
      <td><button class="btn-editar" onclick="alert('Ação para dispositivo: ${d.nome}')"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path fill="none" stroke="#525252" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" d="m5 16l-1 4l4-1L19.586 7.414a2 2 0 0 0 0-2.828l-.172-.172a2 2 0 0 0-2.828 0zM15 6l3 3m-5 11h8"/></svg></button></td>
    </tr>
  `).join('');
}

// Buscar estatísticas
async function carregarEstatisticas() {
  try {
    const res = await fetch(API_STATS_URL);
    if (!res.ok) throw new Error('Erro ao buscar estatísticas');
    const data = await res.json();

    if (data.status !== 'sucesso') throw new Error(data.mensagem || 'Erro na resposta');

    document.getElementById('onlineCount').textContent = data.online || 0;
    document.getElementById('offlineCount').textContent = data.offline || 0;
    document.getElementById('totalCount').textContent = data.total || 0;

  } catch (error) {
    console.error('Erro ao carregar estatísticas:', error);
  }
}

// Atualizações automáticas
async function updateDevices() {
  const devices = await fetchDevices();
  renderDevices(devices);
}

// ========== INÍCIO ==========

// Atualiza ao carregar a página
window.addEventListener('DOMContentLoaded', () => {
  updateDevices();
  carregarEstatisticas();
});

// Atualiza tabela a cada 30 segundos
setInterval(updateDevices, 30000);

// Atualiza cards a cada 60 segundos
setInterval(carregarEstatisticas, 60000);
