from flask import Flask, jsonify
import subprocess
import re
import mysql.connector
from flask_cors import CORS
from datetime import datetime
import socket

app = Flask(__name__)
CORS(app)

# Configuração do banco de dados
db_config = {
    "host": "localhost",
    "user": "root",
    "password": "Panela-123",
    "database": "dispositivos"
}

# Função para obter o IP local da máquina
def get_local_ip():
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        # conecta a um IP externo para descobrir o IP local da interface usada
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
    except Exception:
        ip = "127.0.0.1"
    finally:
        s.close()
    return ip

# Criar tabela no banco de dados se não existir
def criar_tabela():
    try:
        conn = mysql.connector.connect(**db_config)
        cursor = conn.cursor()
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS dispositivos (
                id INT AUTO_INCREMENT PRIMARY KEY,
                nome VARCHAR(100) NOT NULL,
                ip_address VARCHAR(45) NOT NULL,
                mac_address VARCHAR(17) UNIQUE NOT NULL,
                status ENUM('online', 'offline') NOT NULL DEFAULT 'offline',
                ultima_conexao DATETIME
            );
        """)
        conn.commit()
        print("Tabela 'dispositivos' verificada/criada com sucesso.")
    except Exception as e:
        print(f"Erro ao criar tabela: {str(e)}")
    finally:
        if conn.is_connected():
            conn.close()

criar_tabela()

# Endpoint para escanear a rede usando nmap
@app.route('/scan', methods=['GET'])
def scan_network():
    conn = None
    try:
        conn = mysql.connector.connect(**db_config)
        cursor = conn.cursor()

        local_ip = get_local_ip()
        subnet = '.'.join(local_ip.split('.')[:3]) + '.0/24'
        print(f"Iniciando escaneamento de rede na faixa: {subnet}")

        # Executa o nmap para descobrir hosts ativos
        result = subprocess.check_output(["nmap", "-sn", subnet], universal_newlines=True)

        # Regex para extrair IP e MAC do resultado do nmap
        devices = re.finditer(
            r"Nmap scan report for (?:.+?\()?(\d+\.\d+\.\d+\.\d+)(?:\))?.*?MAC Address: ([0-9A-Fa-f:]+)",
            result,
            re.DOTALL
        )

        now = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        encontrados = 0

        for match in devices:
            ip, mac = match.groups()
            mac = mac.upper()
            nome = f"Dispositivo {mac[-5:].replace(':', '')}"

            cursor.execute("""
                INSERT INTO dispositivos (nome, ip_address, mac_address, status, ultima_conexao)
                VALUES (%s, %s, %s, 'online', %s)
                ON DUPLICATE KEY UPDATE
                    ip_address = VALUES(ip_address),
                    status = 'online',
                    ultima_conexao = VALUES(ultima_conexao)
            """, (nome, ip, mac, now))
            encontrados += 1

        # Atualiza status dos dispositivos para offline se não atualizados nos últimos 5 minutos
        cursor.execute("""
            UPDATE dispositivos
            SET status = 'offline'
            WHERE ultima_conexao < DATE_SUB(%s, INTERVAL 5 MINUTE)
        """, (now,))

        conn.commit()
        return jsonify({
            "status": "sucesso",
            "dispositivos_encontrados": encontrados,
            "ultima_varredura": now
        })

    except Exception as e:
        return jsonify({
            "status": "erro",
            "mensagem": "Erro ao escanear a rede",
            "detalhes": str(e)
        }), 500
    finally:
        if conn and conn.is_connected():
            conn.close()

# Endpoint para listar dispositivos cadastrados
@app.route('/devices', methods=['GET'])
def listar_dispositivos():
    conn = None
    try:
        conn = mysql.connector.connect(**db_config)
        cursor = conn.cursor(dictionary=True)

        cursor.execute("""
            SELECT 
                id,
                nome,
                ip_address,
                mac_address,
                status,
                DATE_FORMAT(ultima_conexao, '%Y-%m-%d %H:%i:%s') as ultima_conexao
            FROM dispositivos
            ORDER BY status DESC, ultima_conexao DESC
        """)

        dispositivos = cursor.fetchall()

        return jsonify({
            "status": "sucesso",
            "quantidade": len(dispositivos),
            "dispositivos": dispositivos
        })

    except Exception as e:
        return jsonify({
            "status": "erro",
            "mensagem": "Erro ao listar dispositivos",
            "detalhes": str(e)
        }), 500
    finally:
        if conn and conn.is_connected():
            conn.close()

# Endpoint para obter estatísticas dos dispositivos
@app.route('/stats', methods=['GET'])
def obter_estatisticas():
    conn = None
    try:
        conn = mysql.connector.connect(**db_config)
        cursor = conn.cursor()

        cursor.execute("""
            SELECT
                COUNT(*) as total,
                SUM(status = 'online') as online,
                SUM(status = 'offline') as offline,
                MAX(ultima_conexao) as ultima_varredura
            FROM dispositivos
        """)

        stats = cursor.fetchone()
        return jsonify({
            "status": "sucesso",
            "total": stats[0],
            "online": int(stats[1] or 0),
            "offline": int(stats[2] or 0),
            "ultima_varredura": stats[3].strftime('%Y-%m-%d %H:%M:%S') if stats[3] else None
        })

    except Exception as e:
        return jsonify({
            "status": "erro",
            "mensagem": "Erro ao obter estatísticas",
            "detalhes": str(e)
        }), 500
    finally:
        if conn and conn.is_connected():
            conn.close()

# Endpoint para verificar status do servidor e banco de dados
@app.route('/status', methods=['GET'])
def verificar_status():
    conn = None
    try:
        conn = mysql.connector.connect(**db_config)
        return jsonify({
            "status": "online",
            "banco_dados": "conectado",
            "timestamp": datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        })
    except Exception as e:
        return jsonify({
            "status": "erro",
            "banco_dados": "desconectado",
            "detalhes": str(e)
        }), 500
    finally:
        if conn and conn.is_connected():
            conn.close()

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
